Superstore Analysis Project
Overview
Overview
This document provides a guide on how to analyze return data using various visualizations. The goal is to identify root causes for returned orders by exploring correlations, trends, and patterns in the dataset.

Calculated Field: Returns
Creating the Calculated Field:
Field Name: Returned
Definition: Convert the Returned field into a calculated field where null values are set to 0 and Yes values are set to 1.
Average of Returned Field: Represents the return rate.
Total Returns: Calculated as the count or sum of the Returned field.
Worksheets to Create
1. Scatterplot: Correlation Between Total Sales and Total Returns
Objective: Explore the relationship between total sales and total returns.
Aggregation: Aggregate data by product subcategory.
Analysis: Examine whether higher sales correlate with higher returns. This will help determine if sales volume influences the likelihood of returns.
2. Bar Chart: Return Rate by Product Category
Objective: Visualize the return rate across different product categories.
Chart Type: Bar Chart
Analysis: Identify which product categories have higher return rates. This helps in understanding if certain categories are more prone to returns.
3. Return Rate by Customer
Objective: Identify customers who are more prone to making returns.
Steps:
Filter: Exclude customers with only 1 order.
Chart Type: Bar Chart or another suitable visualization
Analysis: Determine which customers have higher return rates to tailor strategies for these customers.
4. Map: Return Rate by Geographic Measure
Objective: Discover if there is a geographic concentration of returned orders.
Geographic Measure: State, city, or another relevant geographic unit.
Chart Type: Map
Analysis: Identify geographic regions with higher return rates to understand regional trends or issues.
5. Return Rate by Time Measure
Objective: Investigate if there is a seasonal effect on returns.
Time Measure: Month, week, or another relevant time unit.
Chart Type: Line Chart or Bar Chart
Analysis: Determine if returns are seasonal and if certain times of the year see higher return rates.
6. Composite Charts: Return Rate by Multiple Factors
Objective: Analyze return rates across multiple dimensions.
Chart Types:
Composite Chart 1: Date and Geography
Composite Chart 2: Date and Product Category
Analysis: Explore how different combinations of factors (e.g., time and location, or time and product category) affect return rates.
Conclusion
These visualizations will provide a comprehensive view of the return data, helping to identify trends, correlations, and potential root causes of returns. 
By analyzing return rates across various dimensions, you can gain insights into which factors contribute to higher returns and take targeted actions to address them.

Tableau Worksheets
The tableau worksheet with the visualizations for the above analyses is available on Tableau Public. You can view it using the following links:

https://public.tableau.com/app/profile/pierre.philippe5561/viz/Sprintn5_2_1/Sprint5_2_1?publish=yes
https://public.tableau.com/app/profile/pierre.philippe5561/viz/Sprintn5_2_2/Sprint5_2_2?publish=yes
https://public.tableau.com/app/profile/pierre.philippe5561/viz/Sprintn5_2_3/Sprint5_2_3?publish=yes
https://public.tableau.com/app/profile/pierre.philippe5561/viz/Sprintn5_2_4/Sprint5_2_4?publish=yes
https://public.tableau.com/app/profile/pierre.philippe5561/viz/Sprintn5_2_5/Sprint5_2_5?publish=yes
https://public.tableau.com/app/profile/pierre.philippe5561/viz/Sprintn5_2_6/Sprint5_2_6?publish=yes
https://public.tableau.com/app/profile/pierre.philippe5561/viz/Sprintn5_2_6_1/Sprint5_2_6_1?publish=yes

View Tableau Dashboard/Story

https://public.tableau.com/app/profile/pierre.philippe5561/viz/Sprintn5_Dashboard/Sprint5_Dashboard?publish=yes
https://public.tableau.com/app/profile/pierre.philippe5561/viz/Sprintn5_StoryDraft/Sprint5_StoryDraft?publish=yes
https://public.tableau.com/app/profile/pierre.philippe5561/viz/Sprintn5_FinalStory/Sprint5FinalStory

File Structure
README.md - This file
Tableau_Workbook.twbx - Tableau workbook file with the visualizations
Data_Files/ - Directory containing any data files used in the analysis
Open the Tableau Workbook:

Open Tableau_Workbook.twbx in Tableau Desktop to view the visualizations and analyses.

For any questions or further information, please contact Pierre E. Philippe at 
Pierrephiippe77@yahoo.com.
