Business Analytics Project
Project Overview
This project focuses on analyzing user behavior and purchasing patterns for a business. It provides insights into user activity, conversion rates, retention, and cohort trends to better understand customer engagement and improve business decision-making.

Table of Contents
Executive Summary
Data Sources
Analysis Breakdown
Key Metrics
Data Preprocessing
Tools Used
Executive Summary
The Executive Summary outlines the key findings from this analysis, including an overview of user activity, the effectiveness of conversion strategies, and insights into user retention. These insights aim to support business decisions around customer engagement and growth strategies.

Data Sources
Original Raw User Activity: The raw dataset of user activity before cleaning and preprocessing.
Clean Raw User Activity: The cleaned dataset, ready for analysis, after removing inconsistencies and errors.
Purchase Activity: Data on user purchases, including information about frequency, amounts, and purchase behavior over time.
Analysis Breakdown
Cohort Analysis: This sheet breaks down users into groups (or cohorts) based on the date they first interacted with the platform, helping track behavior and retention over time.
Retention Rates: Provides insights into how well the business retains its users over a specified period. This analysis highlights churn rates and patterns in user engagement.
First Purchase Analysis: Focuses on user behavior during their first purchase, including purchase time, frequency, and value.
Conversion Funnel: Tracks the user's journey from their first interaction to the point of making a purchase, helping identify bottlenecks in the process.
Key Metrics
Cohort Retention: The percentage of users retained over a specified period based on their first interaction.
Purchase Activity: Frequency and value of user purchases, including total revenue and average purchase value.
Conversion Rates: Percentage of users who complete key actions, from initial interaction to purchase.
User Engagement: Measures of activity over time, including user interactions and frequency of purchases.
Data Preprocessing
Raw data was cleaned to remove inconsistencies such as missing or erroneous entries.
Outliers were handled to ensure accurate analysis of user behavior and purchasing patterns.
Tools Used
Microsoft Excel: Used for data analysis and cleaning.
Cohort Analysis: Analysis and visualization of user groups over time.
Conversion Funnel Analysis: Tracking and analysis of user actions through the conversion journey.
