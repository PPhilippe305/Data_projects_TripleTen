NYC Airbnb Analysis
Overview
This project analyzes the Airbnb landscape in New York City, focusing on various metrics such as host performance, listing popularity, neighborhood analysis, and review patterns. The dataset contains cleaned data on Airbnb listings scraped from public sources, covering property details, host information, and user reviews.

Skills Utilized
Data Analysis: Extracted key insights from large datasets using data cleaning and transformation techniques.
Business Intelligence (BI) Tools: Power BI was used for visualizing trends in Airbnb listings, including average prices, occupancy rates, and host performance.
Data Cleaning: Cleaned and transformed raw data, ensuring it was prepared for analysis and visualization.
SQL & Excel: Managed and queried large datasets, leveraging Excel for initial exploration and Power BI for advanced visualizations.
Dataset Information
The dataset consists of the following sheets:

Listings (Raw Data): Raw Airbnb listing data.
Calendar: Data on listing availability across different dates.
Top 10 Most Popular Neighborhoods: Popular neighborhoods based on user activity.
Occupancy Average: Average occupancy rates across listings.
Data Cleaning Steps: Steps taken to clean and process the raw data.
Listings (Clean): Cleaned version of the Airbnb listings data, which includes key attributes like listing price, review scores, host details, occupancy rates, and more.
Bedroom Popularity: Popularity of listings based on the number of bedrooms.
Average Price & Occupancy Per Bedroom: Average price and occupancy rates per bedroom type.
Executive Summary: A summary of the key findings from the analysis.
Data Dictionary: Descriptions of the columns in the dataset.
Spare Cleaned Table: Additional cleaned data for backup purposes.
Key Analysis Goals
Host Performance: Analyze how hosts' attributes (e.g., Superhost status, number of listings) affect review scores and occupancy rates.
Neighborhood Popularity: Identify the most popular and highly-rated neighborhoods for Airbnb listings.
Price & Occupancy Trends: Analyze the correlation between price, occupancy rates, and the number of reviews.
Review Insights: Determine patterns in review scores, focusing on cleanliness, location, and value.
Tools
Power BI: Used for interactive visualizations and dashboards to display insights from the data.
Excel: Employed for initial data cleaning and exploration.
SQL: For querying data and extracting specific insights.
Conclusion
This project provides valuable insights into the Airbnb market in NYC, helping hosts and property managers optimize pricing, improve occupancy rates, and identify the most profitable neighborhoods.

